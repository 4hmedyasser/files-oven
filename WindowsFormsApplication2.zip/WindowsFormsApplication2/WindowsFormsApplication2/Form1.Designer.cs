﻿namespace WindowsFormsApplication2
{
    partial class IMPORTINGDATA
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.TXTFILEPATH = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.ROWDELIMITER = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.COLUMNDELIMITER = new System.Windows.Forms.TextBox();
            this.GOTOSECONDFORM = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.EXCELFILEPATH = new System.Windows.Forms.TextBox();
            this.BROWSETEXTFILE = new System.Windows.Forms.Button();
            this.BROWSEEXCELFILE = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(362, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(436, 25);
            this.label1.TabIndex = 1;
            this.label1.Text = "Importing Data and Apply Constraints Model";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(32, 137);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(218, 25);
            this.label2.TabIndex = 2;
            this.label2.Text = "enter the path of the file ";
            // 
            // TXTFILEPATH
            // 
            this.TXTFILEPATH.Location = new System.Drawing.Point(407, 141);
            this.TXTFILEPATH.Name = "TXTFILEPATH";
            this.TXTFILEPATH.Size = new System.Drawing.Size(151, 22);
            this.TXTFILEPATH.TabIndex = 3;
            this.TXTFILEPATH.TextChanged += new System.EventHandler(this.TXTFILEPATH_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(586, 146);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 17);
            this.label3.TabIndex = 4;
            this.label3.Text = "file.txt";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(42, 324);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(171, 25);
            this.label4.TabIndex = 5;
            this.label4.Text = "Enter row delimiter";
            // 
            // ROWDELIMITER
            // 
            this.ROWDELIMITER.Location = new System.Drawing.Point(319, 324);
            this.ROWDELIMITER.Name = "ROWDELIMITER";
            this.ROWDELIMITER.Size = new System.Drawing.Size(136, 22);
            this.ROWDELIMITER.TabIndex = 6;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(575, 320);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(203, 25);
            this.label5.TabIndex = 7;
            this.label5.Text = "Enter column delimiter";
            // 
            // COLUMNDELIMITER
            // 
            this.COLUMNDELIMITER.Location = new System.Drawing.Point(964, 323);
            this.COLUMNDELIMITER.Name = "COLUMNDELIMITER";
            this.COLUMNDELIMITER.Size = new System.Drawing.Size(100, 22);
            this.COLUMNDELIMITER.TabIndex = 8;
            // 
            // GOTOSECONDFORM
            // 
            this.GOTOSECONDFORM.Location = new System.Drawing.Point(507, 464);
            this.GOTOSECONDFORM.Name = "GOTOSECONDFORM";
            this.GOTOSECONDFORM.Size = new System.Drawing.Size(247, 29);
            this.GOTOSECONDFORM.TabIndex = 9;
            this.GOTOSECONDFORM.Text = "Next ";
            this.GOTOSECONDFORM.UseVisualStyleBackColor = true;
            this.GOTOSECONDFORM.Click += new System.EventHandler(this.GOTOSECONDFORM_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(586, 242);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(67, 17);
            this.label6.TabIndex = 10;
            this.label6.Text = "Excel file ";
            // 
            // EXCELFILEPATH
            // 
            this.EXCELFILEPATH.Location = new System.Drawing.Point(394, 226);
            this.EXCELFILEPATH.Name = "EXCELFILEPATH";
            this.EXCELFILEPATH.Size = new System.Drawing.Size(164, 22);
            this.EXCELFILEPATH.TabIndex = 11;
            // 
            // BROWSETEXTFILE
            // 
            this.BROWSETEXTFILE.Location = new System.Drawing.Point(269, 143);
            this.BROWSETEXTFILE.Name = "BROWSETEXTFILE";
            this.BROWSETEXTFILE.Size = new System.Drawing.Size(115, 23);
            this.BROWSETEXTFILE.TabIndex = 12;
            this.BROWSETEXTFILE.Text = "Choose file";
            this.BROWSETEXTFILE.UseVisualStyleBackColor = true;
            this.BROWSETEXTFILE.Click += new System.EventHandler(this.BROWSETEXTFILE_Click);
            // 
            // BROWSEEXCELFILE
            // 
            this.BROWSEEXCELFILE.Location = new System.Drawing.Point(269, 226);
            this.BROWSEEXCELFILE.Name = "BROWSEEXCELFILE";
            this.BROWSEEXCELFILE.Size = new System.Drawing.Size(115, 23);
            this.BROWSEEXCELFILE.TabIndex = 13;
            this.BROWSEEXCELFILE.Text = "Choose File";
            this.BROWSEEXCELFILE.UseVisualStyleBackColor = true;
            this.BROWSEEXCELFILE.Click += new System.EventHandler(this.BROWSEEXCELFILE_Click);
            // 
            // IMPORTINGDATA
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1160, 526);
            this.Controls.Add(this.BROWSEEXCELFILE);
            this.Controls.Add(this.BROWSETEXTFILE);
            this.Controls.Add(this.EXCELFILEPATH);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.GOTOSECONDFORM);
            this.Controls.Add(this.COLUMNDELIMITER);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.ROWDELIMITER);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.TXTFILEPATH);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "IMPORTINGDATA";
            this.Text = "Importing Data";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        public System.Windows.Forms.TextBox TXTFILEPATH;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        public System.Windows.Forms.TextBox ROWDELIMITER;
        private System.Windows.Forms.Label label5;
        public System.Windows.Forms.TextBox COLUMNDELIMITER;
        private System.Windows.Forms.Label label6;
        public System.Windows.Forms.TextBox EXCELFILEPATH;
        public System.Windows.Forms.Button GOTOSECONDFORM;
        public System.Windows.Forms.Button BROWSETEXTFILE;
        private System.Windows.Forms.Button BROWSEEXCELFILE;
    }
}


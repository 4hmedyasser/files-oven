﻿namespace WindowsFormsApplication2
{
    partial class EDITCOLUMN
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.RETURNFROMEDITCOLUMNTOHOMEPAGE = new System.Windows.Forms.Button();
            this.RETURNTOSELECTANOTHERCOLUMNORDER = new System.Windows.Forms.Button();
            this.ISNULL = new System.Windows.Forms.CheckBox();
            this.ISNOTNULL = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.HASDEFAULTVALUE = new System.Windows.Forms.CheckBox();
            this.HASNODEFAULTVALUE = new System.Windows.Forms.CheckBox();
            this.SELECTTHEDEFAULTVALUE = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.HASUNIQUEVALUE = new System.Windows.Forms.CheckBox();
            this.HASNOUNIQUEVALUE = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.FIRSTCONDITION = new System.Windows.Forms.ComboBox();
            this.FIRSTNUMBERSELECTEDASCONDITION = new System.Windows.Forms.TextBox();
            this.SECONDCONDITION = new System.Windows.Forms.ComboBox();
            this.SECONDNUMBERSELECTEDASACONDITION = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.ENDSELECTION = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // RETURNFROMEDITCOLUMNTOHOMEPAGE
            // 
            this.RETURNFROMEDITCOLUMNTOHOMEPAGE.Location = new System.Drawing.Point(130, 454);
            this.RETURNFROMEDITCOLUMNTOHOMEPAGE.Name = "RETURNFROMEDITCOLUMNTOHOMEPAGE";
            this.RETURNFROMEDITCOLUMNTOHOMEPAGE.Size = new System.Drawing.Size(185, 57);
            this.RETURNFROMEDITCOLUMNTOHOMEPAGE.TabIndex = 0;
            this.RETURNFROMEDITCOLUMNTOHOMEPAGE.Text = "Home";
            this.RETURNFROMEDITCOLUMNTOHOMEPAGE.UseVisualStyleBackColor = true;
            this.RETURNFROMEDITCOLUMNTOHOMEPAGE.Click += new System.EventHandler(this.button1_Click);
            // 
            // RETURNTOSELECTANOTHERCOLUMNORDER
            // 
            this.RETURNTOSELECTANOTHERCOLUMNORDER.Location = new System.Drawing.Point(523, 454);
            this.RETURNTOSELECTANOTHERCOLUMNORDER.Name = "RETURNTOSELECTANOTHERCOLUMNORDER";
            this.RETURNTOSELECTANOTHERCOLUMNORDER.Size = new System.Drawing.Size(172, 57);
            this.RETURNTOSELECTANOTHERCOLUMNORDER.TabIndex = 1;
            this.RETURNTOSELECTANOTHERCOLUMNORDER.Text = "Select Column";
            this.RETURNTOSELECTANOTHERCOLUMNORDER.UseVisualStyleBackColor = true;
            this.RETURNTOSELECTANOTHERCOLUMNORDER.Click += new System.EventHandler(this.button2_Click);
            // 
            // ISNULL
            // 
            this.ISNULL.AutoSize = true;
            this.ISNULL.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ISNULL.Location = new System.Drawing.Point(165, 100);
            this.ISNULL.Name = "ISNULL";
            this.ISNULL.Size = new System.Drawing.Size(83, 36);
            this.ISNULL.TabIndex = 2;
            this.ISNULL.Text = "null";
            this.ISNULL.UseVisualStyleBackColor = true;
            // 
            // ISNOTNULL
            // 
            this.ISNOTNULL.AutoSize = true;
            this.ISNOTNULL.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ISNOTNULL.Location = new System.Drawing.Point(807, 100);
            this.ISNOTNULL.Name = "ISNOTNULL";
            this.ISNOTNULL.Size = new System.Drawing.Size(130, 36);
            this.ISNOTNULL.TabIndex = 3;
            this.ISNOTNULL.Text = "not null";
            this.ISNOTNULL.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(354, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(482, 38);
            this.label1.TabIndex = 4;
            this.label1.Text = "The Column you Have Choosen";
            // 
            // HASDEFAULTVALUE
            // 
            this.HASDEFAULTVALUE.AutoSize = true;
            this.HASDEFAULTVALUE.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HASDEFAULTVALUE.Location = new System.Drawing.Point(165, 183);
            this.HASDEFAULTVALUE.Name = "HASDEFAULTVALUE";
            this.HASDEFAULTVALUE.Size = new System.Drawing.Size(216, 36);
            this.HASDEFAULTVALUE.TabIndex = 5;
            this.HASDEFAULTVALUE.Text = " Default Value";
            this.HASDEFAULTVALUE.UseVisualStyleBackColor = true;
            // 
            // HASNODEFAULTVALUE
            // 
            this.HASNODEFAULTVALUE.AutoSize = true;
            this.HASNODEFAULTVALUE.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HASNODEFAULTVALUE.Location = new System.Drawing.Point(807, 183);
            this.HASNODEFAULTVALUE.Name = "HASNODEFAULTVALUE";
            this.HASNODEFAULTVALUE.Size = new System.Drawing.Size(252, 36);
            this.HASNODEFAULTVALUE.TabIndex = 6;
            this.HASNODEFAULTVALUE.Text = "No Default Value";
            this.HASNODEFAULTVALUE.UseVisualStyleBackColor = true;
            // 
            // SELECTTHEDEFAULTVALUE
            // 
            this.SELECTTHEDEFAULTVALUE.Location = new System.Drawing.Point(431, 195);
            this.SELECTTHEDEFAULTVALUE.Name = "SELECTTHEDEFAULTVALUE";
            this.SELECTTHEDEFAULTVALUE.Size = new System.Drawing.Size(100, 22);
            this.SELECTTHEDEFAULTVALUE.TabIndex = 7;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(567, 198);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(155, 17);
            this.label2.TabIndex = 8;
            this.label2.Text = "Enter the default value ";
            // 
            // HASUNIQUEVALUE
            // 
            this.HASUNIQUEVALUE.AutoSize = true;
            this.HASUNIQUEVALUE.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HASUNIQUEVALUE.Location = new System.Drawing.Point(165, 271);
            this.HASUNIQUEVALUE.Name = "HASUNIQUEVALUE";
            this.HASUNIQUEVALUE.Size = new System.Drawing.Size(209, 36);
            this.HASUNIQUEVALUE.TabIndex = 9;
            this.HASUNIQUEVALUE.Text = "Unique Value";
            this.HASUNIQUEVALUE.UseVisualStyleBackColor = true;
            this.HASUNIQUEVALUE.CheckedChanged += new System.EventHandler(this.checkBox5_CheckedChanged);
            // 
            // HASNOUNIQUEVALUE
            // 
            this.HASNOUNIQUEVALUE.AutoSize = true;
            this.HASNOUNIQUEVALUE.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HASNOUNIQUEVALUE.Location = new System.Drawing.Point(807, 271);
            this.HASNOUNIQUEVALUE.Name = "HASNOUNIQUEVALUE";
            this.HASNOUNIQUEVALUE.Size = new System.Drawing.Size(252, 36);
            this.HASNOUNIQUEVALUE.TabIndex = 10;
            this.HASNOUNIQUEVALUE.Text = "No Unique Value";
            this.HASNOUNIQUEVALUE.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(39, 372);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(286, 25);
            this.label3.TabIndex = 11;
            this.label3.Text = "The condition you want to apply";
            // 
            // FIRSTCONDITION
            // 
            this.FIRSTCONDITION.FormattingEnabled = true;
            this.FIRSTCONDITION.Items.AddRange(new object[] {
            "greater than",
            "greater than or equal",
            "less than ",
            "less than or equal ",
            "equal ",
            "not equal"});
            this.FIRSTCONDITION.Location = new System.Drawing.Point(410, 376);
            this.FIRSTCONDITION.Name = "FIRSTCONDITION";
            this.FIRSTCONDITION.Size = new System.Drawing.Size(121, 24);
            this.FIRSTCONDITION.TabIndex = 60;
            this.FIRSTCONDITION.Text = "greater than";
            this.FIRSTCONDITION.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // FIRSTNUMBERSELECTEDASCONDITION
            // 
            this.FIRSTNUMBERSELECTEDASCONDITION.Location = new System.Drawing.Point(595, 378);
            this.FIRSTNUMBERSELECTEDASCONDITION.Name = "FIRSTNUMBERSELECTEDASCONDITION";
            this.FIRSTNUMBERSELECTEDASCONDITION.Size = new System.Drawing.Size(100, 22);
            this.FIRSTNUMBERSELECTEDASCONDITION.TabIndex = 61;
            // 
            // SECONDCONDITION
            // 
            this.SECONDCONDITION.FormattingEnabled = true;
            this.SECONDCONDITION.Items.AddRange(new object[] {
            "greater than",
            "greater than or equal ",
            "less than",
            "less than or equal  ",
            "equal ",
            "not equal"});
            this.SECONDCONDITION.Location = new System.Drawing.Point(798, 375);
            this.SECONDCONDITION.Name = "SECONDCONDITION";
            this.SECONDCONDITION.Size = new System.Drawing.Size(121, 24);
            this.SECONDCONDITION.TabIndex = 80;
            this.SECONDCONDITION.Text = "greater than";
            // 
            // SECONDNUMBERSELECTEDASACONDITION
            // 
            this.SECONDNUMBERSELECTEDASACONDITION.Location = new System.Drawing.Point(959, 375);
            this.SECONDNUMBERSELECTEDASACONDITION.Name = "SECONDNUMBERSELECTEDASACONDITION";
            this.SECONDNUMBERSELECTEDASACONDITION.Size = new System.Drawing.Size(100, 22);
            this.SECONDNUMBERSELECTEDASACONDITION.TabIndex = 84;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(741, 378);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(17, 17);
            this.label4.TabIndex = 85;
            this.label4.Text = "&&";
            // 
            // ENDSELECTION
            // 
            this.ENDSELECTION.Location = new System.Drawing.Point(839, 454);
            this.ENDSELECTION.Name = "ENDSELECTION";
            this.ENDSELECTION.Size = new System.Drawing.Size(157, 57);
            this.ENDSELECTION.TabIndex = 86;
            this.ENDSELECTION.Text = "Finish ";
            this.ENDSELECTION.UseVisualStyleBackColor = true;
            // 
            // EDITCOLUMN
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1203, 532);
            this.Controls.Add(this.ENDSELECTION);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.SECONDNUMBERSELECTEDASACONDITION);
            this.Controls.Add(this.SECONDCONDITION);
            this.Controls.Add(this.FIRSTNUMBERSELECTEDASCONDITION);
            this.Controls.Add(this.FIRSTCONDITION);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.HASNOUNIQUEVALUE);
            this.Controls.Add(this.HASUNIQUEVALUE);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.SELECTTHEDEFAULTVALUE);
            this.Controls.Add(this.HASNODEFAULTVALUE);
            this.Controls.Add(this.HASDEFAULTVALUE);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ISNOTNULL);
            this.Controls.Add(this.ISNULL);
            this.Controls.Add(this.RETURNTOSELECTANOTHERCOLUMNORDER);
            this.Controls.Add(this.RETURNFROMEDITCOLUMNTOHOMEPAGE);
            this.Name = "EDITCOLUMN";
            this.Text = "Edit Column";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        public System.Windows.Forms.CheckBox ISNULL;
        public System.Windows.Forms.CheckBox ISNOTNULL;
        public System.Windows.Forms.CheckBox HASDEFAULTVALUE;
        public System.Windows.Forms.CheckBox HASNODEFAULTVALUE;
        public System.Windows.Forms.Button RETURNFROMEDITCOLUMNTOHOMEPAGE;
        public System.Windows.Forms.Button RETURNTOSELECTANOTHERCOLUMNORDER;
        public System.Windows.Forms.TextBox SELECTTHEDEFAULTVALUE;
        public System.Windows.Forms.CheckBox HASUNIQUEVALUE;
        public System.Windows.Forms.CheckBox HASNOUNIQUEVALUE;
        public System.Windows.Forms.ComboBox FIRSTCONDITION;
        public System.Windows.Forms.TextBox FIRSTNUMBERSELECTEDASCONDITION;
        public System.Windows.Forms.ComboBox SECONDCONDITION;
        public System.Windows.Forms.TextBox SECONDNUMBERSELECTEDASACONDITION;
        public System.Windows.Forms.Button ENDSELECTION;
    }
}
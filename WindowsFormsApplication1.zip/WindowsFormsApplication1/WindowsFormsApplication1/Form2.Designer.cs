﻿namespace WindowsFormsApplication1
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.NOTNULLCONDITION = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.DEFAULTVALUECONDITION = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.UNIQUEVALUECONDITION = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.OPERATIONSANDCONDITIONS = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(43, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(385, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Enter the order of columns which is not null ";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // NOTNULLCONDITION
            // 
            this.NOTNULLCONDITION.Location = new System.Drawing.Point(48, 80);
            this.NOTNULLCONDITION.Name = "NOTNULLCONDITION";
            this.NOTNULLCONDITION.Size = new System.Drawing.Size(641, 22);
            this.NOTNULLCONDITION.TabIndex = 1;
            this.NOTNULLCONDITION.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(239, 137);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 17);
            this.label2.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(966, 82);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(251, 20);
            this.label3.TabIndex = 3;
            this.label3.Text = "Seperate between them using\",\" ";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(284, 137);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 17);
            this.label4.TabIndex = 4;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(43, 137);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(646, 25);
            this.label5.TabIndex = 5;
            this.label5.Text = "enter the order of column which ha default value  &&  Enter it\'s default value";
            // 
            // DEFAULTVALUECONDITION
            // 
            this.DEFAULTVALUECONDITION.Location = new System.Drawing.Point(48, 200);
            this.DEFAULTVALUECONDITION.Name = "DEFAULTVALUECONDITION";
            this.DEFAULTVALUECONDITION.Size = new System.Drawing.Size(641, 22);
            this.DEFAULTVALUECONDITION.TabIndex = 6;
            this.DEFAULTVALUECONDITION.TextChanged += new System.EventHandler(this.textBox1_TextChanged_1);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(789, 200);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(428, 20);
            this.label6.TabIndex = 7;
            this.label6.Text = "Seperate between column and it\'s default value using \"-\"";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(45, 259);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(429, 25);
            this.label7.TabIndex = 8;
            this.label7.Text = "Enter the order of columns that has unique value";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(966, 310);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(249, 20);
            this.label8.TabIndex = 9;
            this.label8.Text = "seperate between them using \",\"";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // UNIQUEVALUECONDITION
            // 
            this.UNIQUEVALUECONDITION.Location = new System.Drawing.Point(48, 310);
            this.UNIQUEVALUECONDITION.Name = "UNIQUEVALUECONDITION";
            this.UNIQUEVALUECONDITION.Size = new System.Drawing.Size(641, 22);
            this.UNIQUEVALUECONDITION.TabIndex = 10;
            this.UNIQUEVALUECONDITION.TextChanged += new System.EventHandler(this.UNIQUEVALUECONDITION_TextChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(45, 362);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(733, 25);
            this.label9.TabIndex = 11;
            this.label9.Text = "Enter the Order of the columns && the operations you want to make on each of them" +
    "  ";
            // 
            // OPERATIONSANDCONDITIONS
            // 
            this.OPERATIONSANDCONDITIONS.Location = new System.Drawing.Point(50, 428);
            this.OPERATIONSANDCONDITIONS.Name = "OPERATIONSANDCONDITIONS";
            this.OPERATIONSANDCONDITIONS.Size = new System.Drawing.Size(628, 22);
            this.OPERATIONSANDCONDITIONS.TabIndex = 12;
            this.OPERATIONSANDCONDITIONS.TextChanged += new System.EventHandler(this.OPERATIONSANDCONDITIONS_TextChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(701, 428);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(557, 20);
            this.label10.TabIndex = 13;
            this.label10.Text = "Seperate Between the columns  using \",\"  && between operations  using \"-\"";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(496, 490);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(246, 23);
            this.button1.TabIndex = 14;
            this.button1.Text = "Home";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1270, 525);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.OPERATIONSANDCONDITIONS);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.UNIQUEVALUECONDITION);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.DEFAULTVALUECONDITION);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.NOTNULLCONDITION);
            this.Controls.Add(this.label1);
            this.Name = "Form2";
            this.Text = "Enter the order  of the columns which has unique values";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button button1;
        public System.Windows.Forms.TextBox NOTNULLCONDITION;
        public System.Windows.Forms.TextBox DEFAULTVALUECONDITION;
        public System.Windows.Forms.TextBox UNIQUEVALUECONDITION;
        public System.Windows.Forms.TextBox OPERATIONSANDCONDITIONS;




    }
}
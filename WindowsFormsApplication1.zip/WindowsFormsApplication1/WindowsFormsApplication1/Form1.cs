﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Xml;
using ExcelDataReader;







namespace WindowsFormsApplication1



{
    public partial class IMPORTINGDATA : Form
    {
        public IMPORTINGDATA()
        {
            InitializeComponent();
        }
        DataSet result;

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Filepath_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void GOTOSECONDFORM_Click(object sender, EventArgs e)
        {
            Form2 Openform = new Form2();
            Openform.Show();
            this.Visible = false;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        

        private void OPENEXCEL_Click(object sender, EventArgs e)
        {
          
            using (OpenFileDialog ofd = new OpenFileDialog() { Filter = "Excel Work Book 97-2003|*.xls|Excel Workbook|* .xlsx", ValidateNames = true })
            {
                
                    if (ofd.ShowDialog() == DialogResult.OK)
                    {

                        FileStream fs = File.Open(ofd.FileName, FileMode.Open, FileAccess.Read);

                        IExcelDataReader reader;
                         if (ofd.FilterIndex==1)
                             reader = ExcelReaderFactory.CreateBinaryReader(fs);
                        
                         else
                             reader = ExcelReaderFactory.CreateOpenXmlReader(fs);

                          result = reader.AsDataSet(new ExcelDataSetConfiguration()
                         {

                             ConfigureDataTable = (tablereader) => new ExcelDataTableConfiguration()
                             {
                                 UseHeaderRow = true
                             }
                         });
                       

                        COMBOSHEET.Items.Clear();
                        foreach (DataTable dt in result.Tables)
                        {
                            COMBOSHEET.Items.Add(dt.TableName);
                        }
                        reader.Close();
                    }
              

              
                
            
            }
        }
        

        private void COMBOSHEET_SelectedIndexChanged(object sender, EventArgs e)
        {

            dataGridView.DataSource = result.Tables[COMBOSHEET.SelectedIndex];
        }

        private void dataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }
    }
}
